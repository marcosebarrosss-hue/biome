import React, { useRef, useEffect, useState } from 'react';
import { User, Biome, BiomeId } from '../../types';
import { useTheme, useAdminEdit } from '../../App';
import { Lock, CheckCircle, MapPin, Edit } from 'lucide-react';
import EditableImage from '../common/EditableImage';
import BiomeEditModal from '../admin/BiomeEditModal';
import PlayerAvatar from '../common/PlayerAvatar';

interface GameMapProps {
  user?: User; // Opcional, pois o admin não é um jogador
  biomes: Biome[];
  onBiomeClick: (biomeId: BiomeId) => void;
}

const GameMap: React.FC<GameMapProps> = ({ user, biomes, onBiomeClick }) => {
  const theme = useTheme();
  const adminContext = useAdminEdit();
  const mapRef = useRef<HTMLDivElement>(null);
  const [editingBiome, setEditingBiome] = useState<Biome | null>(null);

  const lastCompletedBiome = user ? biomes.find(b => b.id === user.completedBiomes[user.completedBiomes.length - 1]) : undefined;
  const currentBiome = user ? (lastCompletedBiome ? biomes.find(b => b.id === lastCompletedBiome.unlocks) : biomes.find(b => b.id === BiomeId.Oceano)) : undefined;

  const handlePinDrag = (id: BiomeId, position: { top: string; left: string }) => {
      adminContext?.setBiomes(prevBiomes => 
        prevBiomes.map(b => b.id === id ? { ...b, mapPosition: position } : b)
      );
  };
  
  const handlePinClick = (id: BiomeId) => {
      const biomeToEdit = adminContext?.biomes.find(b => b.id === id);
      if (biomeToEdit) {
        setEditingBiome(biomeToEdit);
      }
  };

  const handleSaveBiome = (updatedBiome: Biome) => {
    adminContext?.setBiomes(prevBiomes =>
      prevBiomes.map(b => b.id === updatedBiome.id ? updatedBiome : b)
    );
    setEditingBiome(null);
  };

  return (
    <div ref={mapRef} className={`w-full relative bg-cover bg-center bg-no-repeat ${theme.mapHeight}`}>
       <EditableImage
         src={theme.mapImageUrl}
         alt="Mapa do Brasil"
         className="absolute inset-0 w-full h-full"
         containerClassName="absolute inset-0 w-full h-full overflow-hidden"
         style={{
            objectFit: theme.mapImageObjectFit,
            objectPosition: theme.mapImageObjectPosition,
            transform: `scale(${theme.mapImageScale})`,
            width: '100%',
            height: '100%',
            transition: 'transform 0.2s ease-in-out',
         }}
         onImageChange={(newSrc) => adminContext?.setTheme(t => ({...t, mapImageUrl: newSrc}))}
       />
       
       {adminContext?.isEditMode ? (
          biomes.map((biome) => (
            <DraggablePin key={biome.id} biome={biome} onDrag={handlePinDrag} onClick={handlePinClick} mapRef={mapRef} />
          ))
       ) : (
          biomes.map((biome) => {
              const status = !user ? 'completed' : (user.completedBiomes.includes(biome.id) ? 'completed' : 
                            (currentBiome?.id === biome.id ? 'unlocked' : 'locked'));
              
              return (
                <div 
                  key={biome.id}
                  className="absolute transform -translate-x-1/2 -translate-y-1/2 p-2 rounded-lg bg-white/70 dark:bg-black/70 backdrop-blur-sm shadow-lg text-center cursor-pointer"
                  style={{ top: biome.mapPosition.top, left: biome.mapPosition.left }}
                  onClick={() => status !== 'locked' && onBiomeClick(biome.id)}
                >
                    <p className="font-bold text-sm">{biome.name}</p>
                    {user && (
                      <div className="flex justify-center mt-1">
                        {status === 'completed' && <CheckCircle className="w-5 h-5 text-green-500" />}
                        {status === 'locked' && <Lock className="w-5 h-5 text-gray-500" />}
                        {status === 'unlocked' && <MapPin className="w-5 h-5 text-yellow-500 animate-bounce" />}
                      </div>
                    )}
                </div>
              );
          })
       )}

       {currentBiome && user?.avatar && !adminContext?.isEditMode && (
         <div 
           className="absolute transform -translate-x-1/2 -translate-y-1/2 transition-all duration-1000 w-16 h-16 pointer-events-none"
           style={{ top: currentBiome.mapPosition.top, left: currentBiome.mapPosition.left, zIndex: 10 }}
         >
           <div className="w-full h-full animate-bounce">
              <PlayerAvatar user={user} className="w-full h-full rounded-full border-2 border-yellow-400 shadow-lg" />
           </div>
           <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-8 h-2 bg-black/30 rounded-full blur-sm"></div>
         </div>
       )}

       {editingBiome && adminContext && (
         <BiomeEditModal
            biome={editingBiome}
            isOpen={!!editingBiome}
            onClose={() => setEditingBiome(null)}
            onSave={handleSaveBiome}
          />
       )}
    </div>
  );
};

// DraggablePin Component (extracted from original for brevity, no changes)
const DraggablePin: React.FC<{
    biome: Biome;
    onDrag: (id: BiomeId, pos: { top: string; left: string }) => void;
    onClick: (id: BiomeId) => void;
    mapRef: React.RefObject<HTMLDivElement>;
}> = ({ biome, onDrag, onClick, mapRef }) => {
    const pinRef = useRef<HTMLDivElement>(null);
    let clickTimeout: any = null;

    useEffect(() => {
        const pin = pinRef.current;
        if (!pin) return;

        const handleMouseDown = (e: MouseEvent) => {
            e.preventDefault();
            let isDragging = false;
            const startX = e.clientX;
            const startY = e.clientY;

            const map = mapRef.current;
            if (!map) return;

            const handleMouseMove = (moveEvent: MouseEvent) => {
                 if (Math.abs(moveEvent.clientX - startX) > 5 || Math.abs(moveEvent.clientY - startY) > 5) {
                    isDragging = true;
                    if(clickTimeout) clearTimeout(clickTimeout);
                }
                if (!isDragging) return;

                const mapRect = map.getBoundingClientRect();
                const x = moveEvent.clientX - mapRect.left;
                const y = moveEvent.clientY - mapRect.top;
                const leftPercent = Math.max(0, Math.min(100, (x / mapRect.width) * 100));
                const topPercent = Math.max(0, Math.min(100, (y / mapRect.height) * 100));
                
                onDrag(biome.id, { top: `${topPercent.toFixed(2)}%`, left: `${leftPercent.toFixed(2)}%` });
            };
            
            const handleMouseUp = () => {
                if (!isDragging) {
                    onClick(biome.id);
                }
                window.removeEventListener('mousemove', handleMouseMove);
                window.removeEventListener('mouseup', handleMouseUp);
            };

            window.addEventListener('mousemove', handleMouseMove);
            window.addEventListener('mouseup', handleMouseUp);
        };

        pin.addEventListener('mousedown', handleMouseDown);
        return () => { pin.removeEventListener('mousedown', handleMouseDown); };
    }, [onDrag, onClick, biome.id, mapRef]);

    return (
        <div
            ref={pinRef}
            className="absolute p-2 rounded-lg bg-red-500/80 backdrop-blur-sm shadow-lg text-center cursor-grab border-2 border-white text-white flex items-center gap-1"
            style={{ top: biome.mapPosition.top, left: biome.mapPosition.left, transform: 'translate(-50%, -50%)' }}
        >
          <Edit size={14} />
          <p className="font-bold text-sm whitespace-nowrap">{biome.name}</p>
        </div>
    );
};

export default GameMap;