
import { Biome, Item, User } from '../types';
import { BIOMES, REWARD_ITEMS } from '../constants';
import { authService } from './authService';

const BIOMES_KEY = 'aventura_brasil_biomes';
const ITEMS_KEY = 'aventura_brasil_items';

class GameService {
  constructor() {
    this.initializeData();
  }

  private initializeData(): void {
    if (!localStorage.getItem(BIOMES_KEY)) {
      localStorage.setItem(BIOMES_KEY, JSON.stringify(BIOMES));
    }
    if (!localStorage.getItem(ITEMS_KEY)) {
      localStorage.setItem(ITEMS_KEY, JSON.stringify(REWARD_ITEMS));
    }
  }

  getBiomes(): Biome[] {
    const biomesJson = localStorage.getItem(BIOMES_KEY);
    return biomesJson ? JSON.parse(biomesJson) : [];
  }

  getBiomeById(id: string): Biome | undefined {
    return this.getBiomes().find(b => b.id === id);
  }

  getItems(): Item[] {
    const itemsJson = localStorage.getItem(ITEMS_KEY);
    return itemsJson ? JSON.parse(itemsJson) : [];
  }

  getItemById(id: string): Item | undefined {
    return this.getItems().find(i => i.id === id);
  }

  completeBiome(userId: string, biomeId: string): User | null {
    const user = authService.getCurrentUser();
    if (user && user.role === 'player' && user.id === userId) {
        const player = user as User;
        
        if (player.completedBiomes.includes(biomeId as any)) return player;

        const biome = this.getBiomeById(biomeId);
        if (!biome) return null;

        const updatedUser: User = {
            ...player,
            xp: player.xp + 100,
            level: Math.floor((player.xp + 100) / 100) + 1,
            completedBiomes: [...player.completedBiomes, biome.id],
            inventory: [...player.inventory, biome.rewardItemId]
        };
        
        return authService.updateUser(updatedUser);
    }
    return null;
  }
}

export const gameService = new GameService();
