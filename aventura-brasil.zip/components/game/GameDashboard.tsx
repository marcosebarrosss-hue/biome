import React, { useState } from 'react';
import { useAuth, useTheme, useAdminEdit } from '../../App';
import GameHeader from './GameHeader';
import GameMap from './GameMap';
import BiomeModule from './BiomeModule';
import Profile from './Profile';
import Ranking from './Ranking';
import Modal from '../common/Modal';
import { BiomeId, Biome } from '../../types';
import AdminToolbar from '../admin/AdminToolbar';
import EditableBackgroundImage from '../common/EditableBackgroundImage';

interface GameDashboardProps {
  biomes: Biome[];
}

const GameDashboard: React.FC<GameDashboardProps> = ({ biomes }) => {
  const { currentUser, logout } = useAuth();
  const theme = useTheme();
  const adminContext = useAdminEdit();
  
  const [activeBiomeId, setActiveBiomeId] = useState<BiomeId | null>(null);
  const [isProfileOpen, setProfileOpen] = useState(false);
  const [isRankingOpen, setRankingOpen] = useState(false);
  
  if (!currentUser) {
    return <div>Carregando...</div>;
  }
  const isPlayer = currentUser.role === 'player';
  const isAdmin = currentUser.role === 'admin';
  
  const handleBiomeComplete = () => {
    setActiveBiomeId(null);
  };

  const handleBiomeModalBoundsChange = (newBounds: {width: string, height: string, x: number, y: number}) => {
    adminContext?.setTheme(t => ({...t, biomeModuleBounds: newBounds}));
  };

  return (
    <EditableBackgroundImage
      src={theme.dashboardBackgroundImageUrl}
      backgroundSize={theme.dashboardBackgroundSize}
      backgroundPosition={theme.dashboardBackgroundPosition}
      onImageChange={(newSrc) => adminContext?.setTheme(t => ({...t, dashboardBackgroundImageUrl: newSrc}))}
      className="w-full h-screen flex flex-col overflow-hidden"
    >
      {adminContext && <AdminToolbar />}
      
      <GameHeader 
        user={currentUser} 
        onProfileClick={() => setProfileOpen(true)} 
        onRankingClick={() => setRankingOpen(true)} 
        onLogout={logout}
      />
      <main className="flex-grow relative">
        <GameMap 
          user={isPlayer ? currentUser : undefined} 
          biomes={biomes} 
          onBiomeClick={setActiveBiomeId} 
        />
      </main>

      <Modal 
        isOpen={!!activeBiomeId} 
        onClose={() => setActiveBiomeId(null)} 
        title={`Explorando ${activeBiomeId}`} 
        isResizable={isAdmin}
        initialBounds={theme.biomeModuleBounds}
        onBoundsChange={handleBiomeModalBoundsChange}
        maxWidthClass="max-w-2xl" // Fallback for players
      >
        {activeBiomeId && <BiomeModule biomeId={activeBiomeId} onModuleComplete={handleBiomeComplete} />}
      </Modal>

      {isPlayer && (
        <>
          <Modal isOpen={isProfileOpen} onClose={() => setProfileOpen(false)} title="Meu Perfil de Aventureiro">
            <Profile user={currentUser} />
          </Modal>

          <Modal isOpen={isRankingOpen} onClose={() => setRankingOpen(false)} title="Ranking Global de Aventureiros">
            <Ranking />
          </Modal>
        </>
      )}
    </EditableBackgroundImage>
  );
};

export default GameDashboard;