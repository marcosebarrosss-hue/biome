import React, { useState, useEffect } from 'react';
import { Biome, QuizQuestion, BiomeDetail } from '../../types';
import Modal from '../common/Modal';
import Button from '../common/Button';
import { useAdminEdit, useTheme } from '../../App';
import EditableImage from '../common/EditableImage';

interface BiomeEditModalProps {
    biome: Biome;
    isOpen: boolean;
    onClose: () => void;
    onSave: (updatedBiome: Biome) => void;
}

type BiomeDetailSection = 'states' | 'culture' | 'economy';

const BiomeEditModal: React.FC<BiomeEditModalProps> = ({ biome, isOpen, onClose, onSave }) => {
    const [editedBiome, setEditedBiome] = useState(biome);
    const adminContext = useAdminEdit();
    const theme = useTheme();
    const allItems = adminContext?.items ?? [];

    useEffect(() => {
        setEditedBiome(biome);
    }, [biome]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setEditedBiome(prev => ({ ...prev, [name]: value }));
    };
    
    const handleDetailChange = (section: BiomeDetailSection, field: keyof BiomeDetail, value: string) => {
        setEditedBiome(prev => ({
            ...prev,
            [section]: { ...prev[section], [field]: value }
        }));
    };
    
    const handleConservationChange = (field: keyof BiomeDetail, value: string) => {
         setEditedBiome(prev => ({
            ...prev,
            conservation: { 
                ...prev.conservation, 
                status: { ...prev.conservation.status, [field]: value } 
            }
        }));
    };

    const handleQuizChange = (index: number, field: keyof QuizQuestion, value: string) => {
        const newQuiz = [...editedBiome.quiz];
        if (field === 'options') {
            newQuiz[index] = { ...newQuiz[index], [field]: value.split(',').map(s => s.trim()) };
        } else {
            newQuiz[index] = { ...newQuiz[index], [field]: value as any };
        }
        setEditedBiome(prev => ({...prev, quiz: newQuiz}));
    };
    
    const DetailSectionEditor: React.FC<{
        title: string;
        section: BiomeDetailSection;
        detail: BiomeDetail;
    }> = ({ title, section, detail }) => (
        <div className="space-y-2 p-2 border rounded dark:border-gray-600">
            <label className="block font-semibold">{title}</label>
            <textarea value={detail.text} onChange={(e) => handleDetailChange(section, 'text', e.target.value)} className="w-full p-2 border rounded dark:bg-gray-700 h-24" placeholder="Texto descritivo..." />
            <div className="flex items-center gap-4">
                <EditableImage
                    src={detail.imageUrl || theme.placeholderImageUrl}
                    alt={`${title} image`}
                    onImageChange={(newSrc) => handleDetailChange(section, 'imageUrl', newSrc)}
                    onImageRemove={() => handleDetailChange(section, 'imageUrl', '')}
                    containerClassName="w-24 h-24 flex-shrink-0"
                    className="w-full h-full object-cover rounded-lg"
                />
                <input value={detail.videoUrl || ''} onChange={(e) => handleDetailChange(section, 'videoUrl', e.target.value)} className="w-full p-2 border rounded dark:bg-gray-700" placeholder="URL do Vídeo do YouTube (opcional)..." />
            </div>
        </div>
    );

    return (
        <Modal 
            isOpen={isOpen} 
            onClose={onClose} 
            title={`Editando ${biome.name}`} 
            isResizable
            initialBounds={{width: '600px', height: '80vh'}}
        >
            <div className="space-y-4 h-full flex flex-col">
                <div className="overflow-y-auto pr-2 flex-grow space-y-4">
                    <div>
                        <label className="block font-semibold">Nome</label>
                        <input name="name" value={editedBiome.name} onChange={handleChange} className="w-full p-2 border rounded dark:bg-gray-700" />
                    </div>
                    <div>
                        <label className="block font-semibold">Descrição Principal</label>
                        <textarea name="description" value={editedBiome.description} onChange={handleChange} className="w-full p-2 border rounded dark:bg-gray-700 h-24" />
                    </div>

                    <DetailSectionEditor title="Estados" section="states" detail={editedBiome.states} />
                    <DetailSectionEditor title="Cultura" section="culture" detail={editedBiome.culture} />
                    <DetailSectionEditor title="Economia" section="economy" detail={editedBiome.economy} />
                    
                    <div className="space-y-2 p-2 border rounded dark:border-gray-600">
                        <label className="block font-semibold">Status de Conservação</label>
                         <textarea value={editedBiome.conservation.status.text} onChange={(e) => handleConservationChange('text', e.target.value)} className="w-full p-2 border rounded dark:bg-gray-700 h-24" placeholder="Texto descritivo..." />
                        <div className="flex items-center gap-4">
                            <EditableImage
                                src={editedBiome.conservation.status.imageUrl || theme.placeholderImageUrl}
                                alt="Conservation image"
                                onImageChange={(newSrc) => handleConservationChange('imageUrl', newSrc)}
                                onImageRemove={() => handleConservationChange('imageUrl', '')}
                                containerClassName="w-24 h-24 flex-shrink-0"
                                className="w-full h-full object-cover rounded-lg"
                            />
                            <input value={editedBiome.conservation.status.videoUrl || ''} onChange={(e) => handleConservationChange('videoUrl', e.target.value)} className="w-full p-2 border rounded dark:bg-gray-700" placeholder="URL do Vídeo do YouTube (opcional)..." />
                        </div>
                    </div>

                    <div>
                        <label className="block font-semibold">Item de Recompensa</label>
                        <select name="rewardItemId" value={editedBiome.rewardItemId} onChange={handleChange} className="w-full p-2 border rounded dark:bg-gray-700">
                            {allItems.map(item => (
                                <option key={item.id} value={item.id}>{item.name}</option>
                            ))}
                        </select>
                    </div>

                    <h4 className="font-bold pt-4 border-t dark:border-gray-600">Quiz</h4>
                    {editedBiome.quiz.map((q, index) => (
                        <div key={index} className="p-2 border rounded dark:border-gray-600 space-y-2">
                            <label className="block text-sm">Pergunta {index+1}</label>
                            <input value={q.question} onChange={(e) => handleQuizChange(index, 'question', e.target.value)} className="w-full p-1 border rounded dark:bg-gray-600"/>
                            <label className="block text-sm">Opções (separadas por vírgula)</label>
                            <input value={q.options.join(', ')} onChange={(e) => handleQuizChange(index, 'options', e.target.value)} className="w-full p-1 border rounded dark:bg-gray-600"/>
                            <label className="block text-sm">Resposta Correta</label>
                            <input value={q.correctAnswer} onChange={(e) => handleQuizChange(index, 'correctAnswer', e.target.value)} className="w-full p-1 border rounded dark:bg-gray-600"/>
                        </div>
                    ))}
                </div>
                <div className="flex justify-end gap-4 mt-6 flex-shrink-0">
                    <Button variant="secondary" onClick={onClose}>Cancelar</Button>
                    <Button onClick={() => onSave(editedBiome)}>Salvar</Button>
                </div>
            </div>
        </Modal>
    );
};

export default BiomeEditModal;
