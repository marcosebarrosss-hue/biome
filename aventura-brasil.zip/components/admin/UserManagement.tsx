import React, { useState, useEffect } from 'react';
import { User, Item } from '../../types';
import { adminService } from '../../services/adminService';
import { useAdminEdit } from '../../App';
import Modal from '../common/Modal';
import Button from '../common/Button';
import EditableImage from '../common/EditableImage';

const UserManagement: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const adminContext = useAdminEdit();
  
  const allItems = adminContext?.items ?? [];
  
  useEffect(() => {
    setUsers(adminService.getAllUsers());
  }, []);

  const handleEdit = (user: User) => {
    setEditingUser(user);
    setIsModalOpen(true);
  };
  
  const handleDelete = (userId: string) => {
    if(window.confirm('Tem certeza que deseja excluir este usuário?')) {
        const updatedUsers = adminService.deleteUser(userId);
        setUsers(updatedUsers);
    }
  };

  const handleSave = () => {
    if (editingUser) {
        const updatedUsers = adminService.updateUser(editingUser);
        setUsers(updatedUsers);
        setIsModalOpen(false);
        setEditingUser(null);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      if (!editingUser) return;
      const { name, value, type } = e.target;
      setEditingUser({ ...editingUser, [name]: type === 'number' ? Number(value) : value });
  };
  
  const handleItemImageChange = (itemId: string, newSrc: string) => {
      adminContext?.setItems(currentItems => 
        currentItems.map(item => item.id === itemId ? { ...item, imageUrl: newSrc } : item)
      );
  };
  
  const userInventoryItems = editingUser 
    ? editingUser.inventory.map(id => allItems.find(item => item.id === id)).filter((i): i is Item => !!i)
    : [];

  return (
    <div>
      <h2 className="text-xl font-bold mb-4">Gerenciar Aventureiros</h2>
      <div className="overflow-x-auto">
        <table className="min-w-full bg-white dark:bg-gray-800">
          <thead>
            <tr>
              <th className="py-2 px-4 border-b">Usuário</th>
              <th className="py-2 px-4 border-b">Nível</th>
              <th className="py-2 px-4 border-b">XP</th>
              <th className="py-2 px-4 border-b">Biomas Concluídos</th>
              <th className="py-2 px-4 border-b">Ações</th>
            </tr>
          </thead>
          <tbody>
            {users.map(user => (
              <tr key={user.id}>
                <td className="py-2 px-4 border-b text-center">{user.username}</td>
                <td className="py-2 px-4 border-b text-center">{user.level}</td>
                <td className="py-2 px-4 border-b text-center">{user.xp}</td>
                <td className="py-2 px-4 border-b text-center">{user.completedBiomes.length}</td>
                <td className="py-2 px-4 border-b text-center">
                  <Button variant="secondary" onClick={() => handleEdit(user)} className="mr-2 text-sm py-1 px-2">Editar</Button>
                  <Button variant="danger" onClick={() => handleDelete(user.id)} className="text-sm py-1 px-2">Excluir</Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      <Modal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        title={`Editando ${editingUser?.username}`} 
        isResizable
        initialBounds={{width: '500px', height: 'auto'}}
      >
          {editingUser && (
              <div className="space-y-4">
                  <div>
                    <label className="block">Username</label>
                    <input name="username" value={editingUser.username} onChange={handleChange} className="w-full p-2 border rounded dark:bg-gray-700" />
                  </div>
                   <div>
                    <label className="block">Senha (deixe em branco para não alterar)</label>
                    <input name="password" type="password" placeholder="Nova senha" onChange={handleChange} className="w-full p-2 border rounded dark:bg-gray-700" />
                  </div>
                  <div>
                    <label className="block">Nível</label>
                    <input name="level" type="number" value={editingUser.level} onChange={handleChange} className="w-full p-2 border rounded dark:bg-gray-700" />
                  </div>
                   <div>
                    <label className="block">XP</label>
                    <input name="xp" type="number" value={editingUser.xp} onChange={handleChange} className="w-full p-2 border rounded dark:bg-gray-700" />
                  </div>

                  <div className="border-t pt-4">
                      <h4 className="font-semibold mb-2">Inventário (Editar Imagem do Item Globalmente)</h4>
                      {userInventoryItems.length > 0 ? (
                        <div className="grid grid-cols-4 gap-4">
                            {userInventoryItems.map(item => (
                                <div key={item.id} className="text-center">
                                    <EditableImage 
                                        src={item.imageUrl}
                                        alt={item.name}
                                        onImageChange={(newSrc) => handleItemImageChange(item.id, newSrc)}
                                        containerClassName="w-20 h-20 mx-auto"
                                        className="w-full h-full object-contain"
                                    />
                                    <p className="text-xs mt-1">{item.name}</p>
                                </div>
                            ))}
                        </div>
                      ) : (
                          <p className="text-sm text-gray-500">O inventário deste usuário está vazio.</p>
                      )}
                  </div>

                  <div className="flex justify-end gap-4 pt-4 border-t">
                      <Button variant="secondary" onClick={() => setIsModalOpen(false)}>Cancelar</Button>
                      <Button onClick={handleSave}>Salvar</Button>
                  </div>
              </div>
          )}
      </Modal>
    </div>
  );
};

export default UserManagement;