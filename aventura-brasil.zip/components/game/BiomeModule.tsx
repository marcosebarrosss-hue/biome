import React, { useState } from 'react';
import { Biome, BiomeId, BiomeDetail } from '../../types';
import { gameService } from '../../services/gameService';
import { useAdminEdit } from '../../App';
import Quiz from './Quiz';
import Button from '../common/Button';
import BiomeEditModal from '../admin/BiomeEditModal';
import { ChevronLeft, ChevronRight, Edit } from 'lucide-react';

interface BiomeModuleProps {
  biomeId: BiomeId;
  onModuleComplete: (biomeId: BiomeId) => void;
}

const getYoutubeEmbedUrl = (url: string | undefined): string | null => {
  if (!url) return null;
  let videoId = null;
  const urlObj = new URL(url);
  if (urlObj.hostname === 'youtu.be') {
    videoId = urlObj.pathname.slice(1);
  } else if (urlObj.hostname.includes('youtube.com')) {
    videoId = urlObj.searchParams.get('v');
  }
  return videoId ? `https://www.youtube.com/embed/${videoId}` : null;
};

const MediaDisplay: React.FC<{ detail: BiomeDetail }> = ({ detail }) => {
  const embedUrl = getYoutubeEmbedUrl(detail.videoUrl);
  return (
    <div className="mt-3 space-y-3">
      {detail.imageUrl && (
        <img src={detail.imageUrl} alt="Imagem do bioma" className="rounded-lg w-full max-w-md mx-auto" />
      )}
      {embedUrl && (
        <div className="aspect-w-16 aspect-h-9">
          <iframe 
            src={embedUrl}
            title="YouTube video player" 
            frameBorder="0" 
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
            allowFullScreen
            className="w-full h-full rounded-lg"
          ></iframe>
        </div>
      )}
    </div>
  );
};


const Carousel: React.FC<{ items: { title: string, content: React.ReactNode }[] }> = ({ items }) => {
    const [currentIndex, setCurrentIndex] = useState(0);

    const next = () => setCurrentIndex((prev) => (prev + 1) % items.length);
    const prev = () => setCurrentIndex((prev) => (prev - 1 + items.length) % items.length);
    
    return (
        <div className="relative w-full overflow-hidden">
            <div className="flex transition-transform duration-500 h-full" style={{ transform: `translateX(-${currentIndex * 100}%)`}}>
                {items.map((item, index) => (
                    <div key={index} className="w-full flex-shrink-0 p-4 overflow-y-auto max-h-[65vh]">
                        <h4 className="text-lg font-bold text-green-600 dark:text-green-400 mb-2">{item.title}</h4>
                        <div>{item.content}</div>
                    </div>
                ))}
            </div>
            <button onClick={prev} className="absolute top-1/2 left-0 transform -translate-y-1/2 bg-white/50 dark:bg-gray-800/50 p-2 rounded-full hover:bg-white dark:hover:bg-gray-700 z-10">
                <ChevronLeft />
            </button>
            <button onClick={next} className="absolute top-1/2 right-0 transform -translate-y-1/2 bg-white/50 dark:bg-gray-800/50 p-2 rounded-full hover:bg-white dark:hover:bg-gray-700 z-10">
                <ChevronRight />
            </button>
        </div>
    );
};

const BiomeModule: React.FC<BiomeModuleProps> = ({ biomeId, onModuleComplete }) => {
  const adminContext = useAdminEdit();
  const biome = adminContext?.biomes.find(b => b.id === biomeId) ?? gameService.getBiomeById(biomeId);

  const [viewMode, setViewMode] = useState<'simple' | 'interactive'>('simple');
  const [showQuiz, setShowQuiz] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  if (!biome) {
    return <div>Carregando bioma...</div>;
  }
  
  const handleSaveBiome = (updatedBiome: Biome) => {
      adminContext?.setBiomes(prevBiomes => 
        prevBiomes.map(b => b.id === updatedBiome.id ? updatedBiome : b)
      );
      setIsEditModalOpen(false);
  };

  const carouselItems = [
      { title: 'Estados', content: <><p>{biome.states.text}</p><MediaDisplay detail={biome.states}/></> },
      { title: 'Cultura', content: <><p>{biome.culture.text}</p><MediaDisplay detail={biome.culture}/></> },
      { title: 'Economia', content: <><p>{biome.economy.text}</p><MediaDisplay detail={biome.economy}/></> },
      { title: 'Conservação', content: <><p><strong>Status:</strong> {biome.conservation.status.text}</p><MediaDisplay detail={biome.conservation.status}/></> },
      { title: 'Espécies Ameaçadas', content: <ul className="list-disc pl-5">{biome.conservation.threatenedSpecies.map(s => <li key={s}>{s}</li>)}</ul> },
  ];

  if (showQuiz) {
    return <Quiz biome={biome} onQuizComplete={() => onModuleComplete(biome.id)} />;
  }

  return (
    <div className="text-gray-800 dark:text-gray-200">
      <div className="flex justify-between items-start">
        <h3 className="text-2xl font-bold mb-4">{biome.name}</h3>
        {adminContext?.isEditMode && (
          <Button variant="secondary" onClick={() => setIsEditModalOpen(true)} className="flex items-center gap-2">
            <Edit size={16} /> Editar Conteúdo
          </Button>
        )}
      </div>

      <p className="mb-6">{biome.description}</p>
      
      <div className="flex justify-center gap-4 mb-6">
        <Button variant={viewMode === 'simple' ? 'primary' : 'secondary'} onClick={() => setViewMode('simple')}>Visualização Simples</Button>
        <Button variant={viewMode === 'interactive' ? 'primary' : 'secondary'} onClick={() => setViewMode('interactive')}>Visualização Interativa</Button>
      </div>

      <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
        {viewMode === 'simple' ? (
          <div className="space-y-4">
            {carouselItems.map(item => (
                <div key={item.title}>
                    <h4 className="text-lg font-bold text-green-600 dark:text-green-400 mb-1">{item.title}</h4>
                    <div>{item.content}</div>
                </div>
            ))}
          </div>
        ) : (
          <Carousel items={carouselItems} />
        )}
      </div>

      <div className="mt-8 text-center">
        <p className="mb-4">Pronto para testar seus conhecimentos?</p>
        <Button onClick={() => setShowQuiz(true)}>Iniciar Desafio!</Button>
      </div>
      
      {adminContext && (
        <BiomeEditModal
          biome={biome}
          isOpen={isEditModalOpen}
          onClose={() => setIsEditModalOpen(false)}
          onSave={handleSaveBiome}
        />
      )}
    </div>
  );
};

export default BiomeModule;