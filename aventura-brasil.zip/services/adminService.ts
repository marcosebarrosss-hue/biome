
import { User, Admin, AppTheme, Biome, Item } from '../types';
import { DEFAULT_THEME, BIOMES, REWARD_ITEMS } from '../constants';

const USERS_KEY = 'aventura_brasil_users';
const THEME_KEY = 'aventura_brasil_theme';
const BIOMES_KEY = 'aventura_brasil_biomes';
const ITEMS_KEY = 'aventura_brasil_items';

class AdminService {

  initializeData(): void {
    if (!localStorage.getItem(USERS_KEY)) {
        localStorage.setItem(USERS_KEY, JSON.stringify([]));
    }
    if (!localStorage.getItem(THEME_KEY)) {
        localStorage.setItem(THEME_KEY, JSON.stringify(DEFAULT_THEME));
    }
    if (!localStorage.getItem(BIOMES_KEY)) {
        localStorage.setItem(BIOMES_KEY, JSON.stringify(BIOMES));
    }
    if (!localStorage.getItem(ITEMS_KEY)) {
        localStorage.setItem(ITEMS_KEY, JSON.stringify(REWARD_ITEMS));
    }
  }

  // User Management
  getAllUsers(): User[] {
    const usersJson = localStorage.getItem(USERS_KEY);
    const allUsers = usersJson ? JSON.parse(usersJson) : [];
    return allUsers.filter((user: User | Admin) => user.role === 'player');
  }
  
  updateUser(updatedUser: User): User[] {
    const users = this.getAllUsers();
    const index = users.findIndex(u => u.id === updatedUser.id);
    if (index !== -1) {
      users[index] = updatedUser;
      this.saveAllUsers(users);
    }
    return users;
  }
  
  deleteUser(userId: string): User[] {
    let users = this.getAllUsers();
    users = users.filter(u => u.id !== userId);
    this.saveAllUsers(users);
    return users;
  }
  
  private saveAllUsers(users: User[]): void {
      const allUsersAndAdmins = localStorage.getItem(USERS_KEY);
      const admins = allUsersAndAdmins ? (JSON.parse(allUsersAndAdmins) as (User|Admin)[]).filter(u => u.role === 'admin') : [];
      localStorage.setItem(USERS_KEY, JSON.stringify([...admins, ...users]));
  }

  // Theme Management
  getTheme(): AppTheme {
    const themeJson = localStorage.getItem(THEME_KEY);
    const savedTheme = themeJson ? JSON.parse(themeJson) : {};
    // Mescla o tema padrão com o tema salvo.
    // Isso garante que quaisquer novas propriedades no DEFAULT_THEME sejam aplicadas,
    // enquanto permite que as preferências salvas pelo usuário as substituam.
    return { ...DEFAULT_THEME, ...savedTheme };
  }

  saveTheme(theme: AppTheme): void {
    localStorage.setItem(THEME_KEY, JSON.stringify(theme));
  }

  // Content Management
  getBiomes(): Biome[] {
    const biomesJson = localStorage.getItem(BIOMES_KEY);
    return biomesJson ? JSON.parse(biomesJson) : [];
  }

  saveBiomes(biomes: Biome[]): void {
    localStorage.setItem(BIOMES_KEY, JSON.stringify(biomes));
  }
  
  getItems(): Item[] {
    const itemsJson = localStorage.getItem(ITEMS_KEY);
    return itemsJson ? JSON.parse(itemsJson) : [];
  }

  saveItems(items: Item[]): void {
    localStorage.setItem(ITEMS_KEY, JSON.stringify(items));
  }
}

export const adminService = new AdminService();