import React, { useState, ChangeEvent, useRef, useEffect } from 'react';
import { useAdminEdit } from '../../App';
import Button from '../common/Button';
import Modal from '../common/Modal';
import UserManagement from './UserManagement';
import ItemManagement from './ItemManagement';
import { Edit, Eye, Save, Users, Palette, X, Image as ImageIcon, BookUser, Move, Map, UserCog } from 'lucide-react';
import { AppTheme } from '../../types';
import EditableImage from '../common/EditableImage';

type Direction = 'nw' | 'ne' | 'sw' | 'se';

const parsePosition = (posStr: string = '50% 50%'): { x: number; y: number } => {
  const parts = posStr.split(' ');
  return {
    x: parseFloat(parts[0]) || 50,
    y: parseFloat(parts[1]) || 50,
  };
};

const parseSize = (sizeStr: string = 'cover'): { type: 'cover' | 'contain' | 'manual'; value: number } => {
  if (sizeStr === 'cover' || sizeStr === 'contain') {
    return { type: sizeStr, value: 100 };
  }
  return { type: 'manual', value: parseFloat(sizeStr) || 100 };
};


const BackgroundControl: React.FC<{
  label: string;
  imageUrl: string;
  onImageChange: (newSrc: string) => void;
  sizeValue: string;
  onSizeChange: (newSize: string) => void;
  positionValue: string;
  onPositionChange: (newPos: string) => void;
}> = ({ label, imageUrl, onImageChange, sizeValue, onSizeChange, positionValue, onPositionChange }) => {
  const { x, y } = parsePosition(positionValue);
  const { type, value: zoom } = parseSize(sizeValue);

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          onImageChange(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleFitChange = (e: ChangeEvent<HTMLSelectElement>) => {
      const newFit = e.target.value;
      if (newFit === 'manual') {
          onSizeChange('100%');
          onPositionChange('50% 50%');
      } else {
          onSizeChange(newFit);
          onPositionChange('50% 50%');
      }
  };

  return (
    <div className="p-2 border dark:border-gray-600 rounded-md space-y-2">
      <label className="block text-sm font-semibold">{label}</label>
      <div className="flex items-center gap-2">
        <img src={imageUrl} alt={label} className="w-10 h-10 object-cover rounded flex-shrink-0" />
        <label className="flex-grow">
          <span className="sr-only">Choose file</span>
          <input type="file" onChange={handleFileChange} accept="image/*" className="block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-green-50 file:text-green-700 hover:file:bg-green-100"/>
        </label>
      </div>
       <select
          value={type}
          onChange={handleFitChange}
          className="w-full p-1 border rounded dark:bg-gray-700 text-xs"
        >
          <option value="cover">Preencher (Cover)</option>
          <option value="contain">Ajustar (Contain)</option>
          <option value="manual">Manual</option>
        </select>
        {type === 'manual' && (
            <div className="text-xs space-y-1 pt-1 border-t dark:border-gray-600">
                <label>Zoom: {zoom.toFixed(0)}%</label>
                <input type="range" min="50" max="300" value={zoom} onChange={e => onSizeChange(`${e.target.value}%`)} className="w-full" />
                <label>Posição X: {x}%</label>
                <input type="range" min="0" max="100" value={x} onChange={e => onPositionChange(`${e.target.value}% ${y}%`)} className="w-full" />
                <label>Posição Y: {y}%</label>
                <input type="range" min="0" max="100" value={y} onChange={e => onPositionChange(`${x}% ${e.target.value}%`)} className="w-full" />
            </div>
        )}
    </div>
  );
};


const AdminToolbar: React.FC = () => {
  const context = useAdminEdit();
  const [isUsersModalOpen, setIsUsersModalOpen] = useState(false);
  const [isToolbarOpen, setIsToolbarOpen] = useState(true);
  const [managementTab, setManagementTab] = useState('users');
  
  const toolbarRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isResizing, setIsResizing] = useState<Direction | null>(null);
  
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [size, setSize] = useState({ width: 384, height: 500 });
  
  const startMousePos = useRef({ x: 0, y: 0 });
  const startSize = useRef({ width: 0, height: 0});
  
  useEffect(() => {
    if (context?.theme.adminToolbarBounds) {
        const { width, height, x, y } = context.theme.adminToolbarBounds;
        const parsedWidth = parseInt(width, 10) || 384;
        
        const initialX = x ?? window.innerWidth - parsedWidth - 16;
        let initialY = y;
        
        let parsedHeight;
        if (height === 'auto') {
            parsedHeight = toolbarRef.current?.offsetHeight || 500;
             if (!y) initialY = window.innerHeight - parsedHeight - 16;
        } else {
            parsedHeight = parseInt(height, 10) || 500;
             if (!y) initialY = window.innerHeight - parsedHeight - 16;
        }
        
        setPosition({ x: initialX, y: initialY as number });
        setSize({ width: parsedWidth, height: parsedHeight });
    }
  }, []); 

  const handleMouseDownDrag = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsDragging(true);
    startMousePos.current = { x: e.clientX - position.x, y: e.clientY - position.y };
  };

  const handleMouseDownResize = (e: React.MouseEvent, direction: Direction) => {
    e.preventDefault();
    e.stopPropagation();
    setIsResizing(direction);
    startMousePos.current = { x: e.clientX, y: e.clientY };
    startSize.current = { width: size.width, height: size.height };
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (isDragging) {
        setPosition({
          x: e.clientX - startMousePos.current.x,
          y: e.clientY - startMousePos.current.y,
        });
      } else if (isResizing) {
        const dx = e.clientX - startMousePos.current.x;
        const dy = e.clientY - startMousePos.current.y;
        
        let newWidth = startSize.current.width;
        let newHeight = startSize.current.height;
        let newX = position.x;
        let newY = position.y;

        if (isResizing.includes('e')) newWidth = startSize.current.width + dx;
        if (isResizing.includes('w')) {
            newWidth = startSize.current.width - dx;
            newX = position.x + dx;
        }
        if (isResizing.includes('s')) newHeight = startSize.current.height + dy;
        if (isResizing.includes('n')) {
            newHeight = startSize.current.height - dy;
            newY = position.y + dy;
        }
        
        const finalWidth = Math.max(320, newWidth);
        const finalHeight = Math.max(200, newHeight);

        if (finalWidth > 320 && isResizing.includes('w')) setPosition(p => ({ ...p, x: newX }));
        if (finalHeight > 200 && isResizing.includes('n')) setPosition(p => ({ ...p, y: newY }));

        setSize({ width: finalWidth, height: finalHeight });
      }
    };
    
    const handleMouseUp = () => {
      if ((isDragging || isResizing) && context) {
          context.setTheme(t => ({
              ...t,
              adminToolbarBounds: {
                  width: `${size.width}px`, 
                  height: `${size.height}px`,
                  x: position.x,
                  y: position.y
              }
          }));
      }
      setIsDragging(false);
      setIsResizing(null);
    };

    if (isDragging || isResizing) {
        window.addEventListener('mousemove', handleMouseMove);
        window.addEventListener('mouseup', handleMouseUp);
    }

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging, isResizing, position, size, context]);


  if (!context) return null;
  const { isEditMode, toggleEditMode, theme, setTheme, saveChanges, setAdminPage } = context;

  if (!isToolbarOpen) {
    return (
      <button
        onClick={() => setIsToolbarOpen(true)}
        className="fixed bottom-4 right-4 z-[100] p-3 bg-red-600 text-white rounded-full shadow-lg hover:bg-red-700"
        aria-label="Abrir barra de ferramentas do admin"
      >
        <Edit size={24} />
      </button>
    );
  }
  
  const handleManagementModalBoundsChange = (newBounds: {width: string, height: string, x: number, y: number}) => {
    setTheme(t => ({...t, managementModalBounds: newBounds}));
  };

  const { x: mapX, y: mapY } = parsePosition(theme.mapImageObjectPosition);
  
  const handleArrayChange = (field: keyof AppTheme, value: string) => {
      setTheme(t => ({...t, [field]: value.split(',').map(s => s.trim())} as any));
  }

  return (
    <>
      <div 
        ref={toolbarRef} 
        className="fixed z-[100] bg-white/80 dark:bg-gray-800/80 backdrop-blur-md rounded-lg shadow-2xl border dark:border-gray-700 p-4 flex flex-col max-h-[95vh]"
        style={{ 
            top: `${position.y}px`, 
            left: `${position.x}px`, 
            width: `${size.width}px`, 
            height: `${size.height}px`
        }}
      >
        {/* Resize Handles */}
        <div onMouseDown={(e) => handleMouseDownResize(e, 'nw')} className="absolute -top-1 -left-1 w-4 h-4 cursor-nwse-resize z-20" />
        <div onMouseDown={(e) => handleMouseDownResize(e, 'ne')} className="absolute -top-1 -right-1 w-4 h-4 cursor-nesw-resize z-20" />
        <div onMouseDown={(e) => handleMouseDownResize(e, 'sw')} className="absolute -bottom-1 -left-1 w-4 h-4 cursor-nesw-resize z-20" />
        <div onMouseDown={(e) => handleMouseDownResize(e, 'se')} className="absolute -bottom-1 -right-1 w-4 h-4 cursor-nwse-resize z-20" />

        <div 
            onMouseDown={handleMouseDownDrag}
            className="flex justify-between items-center mb-4 flex-shrink-0 cursor-move"
        >
          <h3 className="font-bold text-lg flex items-center gap-2"><Move size={16} /> Painel de Edição</h3>
          <button onClick={() => setIsToolbarOpen(false)} className="p-1 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-full">
            <X size={20} />
          </button>
        </div>
        
        <div className="space-y-4 overflow-y-auto pr-2 -mr-2 flex-grow">
          <Button onClick={toggleEditMode} className="w-full flex items-center justify-center gap-2">
            {isEditMode ? <><Eye size={16}/> Visualizar</> : <><Edit size={16}/> Ativar Modo Edição</>}
          </Button>
          
          <div className="border-t dark:border-gray-600 pt-4">
            <h4 className="font-semibold mb-2 flex items-center gap-2"><UserCog size={16} /> Perfil do Administrador</h4>
            <div className="flex items-center gap-4 p-2 border dark:border-gray-600 rounded-md">
                <EditableImage
                    src={theme.adminAvatarUrl}
                    alt="Avatar do Admin"
                    onImageChange={(newSrc) => setTheme(t => ({ ...t, adminAvatarUrl: newSrc }))}
                    allowCropping
                    containerClassName="w-16 h-16 flex-shrink-0"
                    className="w-full h-full object-cover rounded-full"
                />
                <p className="text-sm text-gray-500 dark:text-gray-400">Altere a imagem que aparece no cabeçalho.</p>
            </div>
          </div>

          <div className="border-t dark:border-gray-600 pt-4">
             <h4 className="font-semibold mb-2 flex items-center gap-2"><Palette size={16} /> Design Visual</h4>
             <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm mb-1">Cor Primária</label>
                    <input type="color" value={theme.primaryColor} onChange={e => setTheme(t => ({...t, primaryColor: e.target.value}))} className="w-full h-8 p-0 border-none rounded cursor-pointer" />
                </div>
                 <div>
                    <label className="block text-sm mb-1">Cor Secundária</label>
                    <input type="color" value={theme.secondaryColor} onChange={e => setTheme(t => ({...t, secondaryColor: e.target.value}))} className="w-full h-8 p-0 border-none rounded cursor-pointer" />
                </div>
             </div>
             <div className="mt-2">
                <label className="block text-sm mb-1">Tamanho do Mapa</label>
                <select
                    value={theme.mapHeight}
                    onChange={e => setTheme(t => ({...t, mapHeight: e.target.value as any}))}
                    className="w-full p-2 border rounded dark:bg-gray-700 text-sm"
                >
                    <option value="h-[50vh]">Compacto</option>
                    <option value="h-[70vh]">Padrão</option>
                    <option value="h-full">Imersivo</option>
                </select>
            </div>
          </div>

          <div className="border-t dark:border-gray-600 pt-4 space-y-3">
             <h4 className="font-semibold mb-2 flex items-center gap-2"><Map size={16} /> Fundo do Mapa</h4>
             <div className="p-2 border dark:border-gray-600 rounded-md space-y-2">
                <select
                    value={theme.mapImageObjectFit}
                    onChange={e => setTheme(t => ({...t, mapImageObjectFit: e.target.value as 'cover' | 'contain'}))}
                    className="w-full p-1 border rounded dark:bg-gray-700 text-xs"
                >
                    <option value="cover">Preencher (Cover)</option>
                    <option value="contain">Ajustar (Contain)</option>
                </select>
                <div className="text-xs space-y-1 pt-1 border-t dark:border-gray-600">
                    <label>Zoom: {(theme.mapImageScale * 100).toFixed(0)}%</label>
                    <input type="range" min="0.5" max="3" step="0.01" value={theme.mapImageScale} onChange={e => setTheme(t => ({...t, mapImageScale: parseFloat(e.target.value)}))} className="w-full" />
                    <label>Posição X: {mapX}%</label>
                    <input type="range" min="0" max="100" value={mapX} onChange={e => setTheme(t => ({...t, mapImageObjectPosition: `${e.target.value}% ${mapY}%`}))} className="w-full" />
                    <label>Posição Y: {mapY}%</label>
                    <input type="range" min="0" max="100" value={mapY} onChange={e => setTheme(t => ({...t, mapImageObjectPosition: `${mapX}% ${e.target.value}%`}))} className="w-full" />
                </div>
             </div>
          </div>
          
          <div className="border-t dark:border-gray-600 pt-4 space-y-3">
              <h4 className="font-semibold mb-2 flex items-center gap-2"><ImageIcon size={16} /> Fundos das Páginas</h4>
              <BackgroundControl
                label="Fundo do Dashboard"
                imageUrl={theme.dashboardBackgroundImageUrl}
                onImageChange={(newSrc) => setTheme(t => ({...t, dashboardBackgroundImageUrl: newSrc}))}
                sizeValue={theme.dashboardBackgroundSize}
                onSizeChange={(newSize) => setTheme(t => ({...t, dashboardBackgroundSize: newSize}))}
                positionValue={theme.dashboardBackgroundPosition}
                onPositionChange={(newPos) => setTheme(t => ({...t, dashboardBackgroundPosition: newPos}))}
              />
              <BackgroundControl
                label="Fundo de Login"
                imageUrl={theme.loginBackgroundImageUrl}
                onImageChange={(newSrc) => setTheme(t => ({...t, loginBackgroundImageUrl: newSrc}))}
                sizeValue={theme.loginBackgroundSize}
                onSizeChange={(newSize) => setTheme(t => ({...t, loginBackgroundSize: newSize}))}
                positionValue={theme.loginBackgroundPosition}
                onPositionChange={(newPos) => setTheme(t => ({...t, loginBackgroundPosition: newPos}))}
              />
              <BackgroundControl
                label="Fundo de Registro"
                imageUrl={theme.registerBackgroundImageUrl}
                onImageChange={(newSrc) => setTheme(t => ({...t, registerBackgroundImageUrl: newSrc}))}
                sizeValue={theme.registerBackgroundSize}
                onSizeChange={(newSize) => setTheme(t => ({...t, registerBackgroundSize: newSize}))}
                positionValue={theme.registerBackgroundPosition}
                onPositionChange={(newPos) => setTheme(t => ({...t, registerBackgroundPosition: newPos}))}
              />
          </div>
          
          <div className="border-t dark:border-gray-600 pt-4 flex flex-col gap-2">
             <Button variant="secondary" onClick={() => setIsUsersModalOpen(true)} className="w-full flex items-center justify-center gap-2">
              <Users size={16} /> Gerenciar
            </Button>
            <Button onClick={saveChanges} className="w-full flex items-center justify-center gap-2 bg-green-600 hover:bg-green-700">
                <Save size={16} /> Salvar Tudo
            </Button>
          </div>
        </div>
      </div>

      <Modal 
        isOpen={isUsersModalOpen} 
        onClose={() => setIsUsersModalOpen(false)} 
        title="Gerenciamento" 
        isResizable
        initialBounds={theme.managementModalBounds}
        onBoundsChange={handleManagementModalBoundsChange}
      >
        <div className="flex border-b dark:border-gray-700 mb-4 h-full flex-col">
          <div className="flex-shrink-0">
            <button onClick={() => setManagementTab('users')} className={`px-4 py-2 ${managementTab === 'users' ? 'border-b-2 border-green-500 font-semibold' : ''}`}>Aventureiros</button>
            <button onClick={() => setManagementTab('items')} className={`px-4 py-2 ${managementTab === 'items' ? 'border-b-2 border-green-500 font-semibold' : ''}`}>Itens</button>
          </div>
          <div className="flex-grow overflow-y-auto">
            {managementTab === 'users' ? <UserManagement /> : <ItemManagement />}
          </div>
        </div>
      </Modal>
    </>
  );
};

export default AdminToolbar;