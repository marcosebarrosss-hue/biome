import React, { useState, useRef } from 'react';
import { User, Profession } from '../../types';
import { PROFESSIONS } from '../../constants';
import { authService } from '../../services/authService';
import Button from '../common/Button';
import Modal from '../common/Modal';
import { UploadCloud, ZoomIn, Move } from 'lucide-react';

interface AvatarCreatorProps {
  user: User;
  onAvatarCreated: (user: User) => void;
}

const AvatarCropper: React.FC<{
  imageSrc: string;
  onCropComplete: (croppedImage: string) => void;
  onCancel: () => void;
}> = ({ imageSrc, onCropComplete, onCancel }) => {
  const imageRef = useRef<HTMLImageElement>(null);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState(false);
  const [panStart, setPanStart] = useState({ x: 0, y: 0 });
  const CROP_SIZE = 288; // 72 * 4

  const handleMouseDown = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsPanning(true);
    setPanStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isPanning) {
      setPan({ x: e.clientX - panStart.x, y: e.clientY - panStart.y });
    }
  };
  
  const handleMouseUp = () => setIsPanning(false);

  const handleCrop = () => {
    const image = imageRef.current;
    const canvas = document.createElement('canvas');
    const finalSize = 256;
    canvas.width = finalSize;
    canvas.height = finalSize;
    const ctx = canvas.getContext('2d');

    if (!ctx || !image) return;

    const scaleX = image.naturalWidth / image.width;
    const scaleY = image.naturalHeight / image.height;
    
    const sourceX = ( (image.width / 2) - pan.x - (CROP_SIZE / (2 * zoom)) ) * scaleX;
    const sourceY = ( (image.height / 2) - pan.y - (CROP_SIZE / (2 * zoom)) ) * scaleY;
    const sourceWidth = (CROP_SIZE / zoom) * scaleX;
    const sourceHeight = (CROP_SIZE / zoom) * scaleY;
    
    ctx.drawImage(
      image,
      sourceX,
      sourceY,
      sourceWidth,
      sourceHeight,
      0,
      0,
      finalSize,
      finalSize
    );

    onCropComplete(canvas.toDataURL('image/png'));
  };

  return (
    <Modal isOpen={true} onClose={onCancel} title="Ajuste seu Avatar">
      <div className="flex flex-col items-center">
        <p className="mb-4 text-center text-gray-600 dark:text-gray-300">Arraste para mover e use o controle para ampliar.</p>
        <div 
          className="w-72 h-72 rounded-full overflow-hidden relative bg-gray-200 dark:bg-gray-700 cursor-move"
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
        >
          <img
            ref={imageRef}
            src={imageSrc}
            alt="Avatar para recortar"
            className="absolute top-1/2 left-1/2"
            style={{
              transform: `translate(-50%, -50%) translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
              transition: isPanning ? 'none' : 'transform 0.1s ease-out',
            }}
            onLoad={(e) => { // Reset pan/zoom on new image
                setPan({x:0, y:0});
                setZoom(1);
            }}
          />
        </div>
        <div className="w-72 mt-4 flex items-center gap-4">
          <ZoomIn className="text-gray-500" />
          <input
            type="range"
            min="1"
            max="3"
            step="0.01"
            value={zoom}
            onChange={(e) => setZoom(parseFloat(e.target.value))}
            className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-600"
          />
        </div>
        <div className="mt-6 flex gap-4">
          <Button variant="secondary" onClick={onCancel}>Cancelar</Button>
          <Button onClick={handleCrop}>Confirmar Ajuste</Button>
        </div>
      </div>
    </Modal>
  );
};


const AvatarCreator: React.FC<AvatarCreatorProps> = ({ user, onAvatarCreated }) => {
  const [profession, setProfession] = useState<Profession>(PROFESSIONS[0]);
  const [croppedImage, setCroppedImage] = useState<string | null>(null);
  const [imageToCrop, setImageToCrop] = useState<string | null>(null);
  const [error, setError] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = (file: File) => {
    if (file && file.type.startsWith('image/')) {
       if (file.size > 5 * 1024 * 1024) { // 5MB limit
        setError('A imagem é muito grande. O limite é de 5MB.');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setImageToCrop(reader.result as string);
        setError('');
      };
      reader.readAsDataURL(file);
    } else {
       setError('Por favor, selecione um arquivo de imagem válido.');
    }
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if(file) handleImageUpload(file);
    e.target.value = ''; // Reset input to allow re-uploading the same file
  };
  
  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
      e.preventDefault();
      e.stopPropagation();
      const file = e.dataTransfer.files?.[0];
      if(file) handleImageUpload(file);
  };

  const handleCreate = () => {
    if (!croppedImage) {
      setError('Por favor, faça o upload e confirme a imagem para o seu avatar.');
      return;
    }
    const updatedUser: User = { 
      ...user, 
      avatar: { imageUrl: croppedImage }, 
      profession 
    };
    authService.updateUser(updatedUser);
    onAvatarCreated(updatedUser);
  };
  
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-green-50 dark:bg-gray-800">
      <div className="w-full max-w-2xl bg-white dark:bg-gray-900 rounded-2xl shadow-xl p-8 text-center">
        <h1 className="text-3xl font-bold text-green-700 dark:text-green-400">Crie seu Aventureiro</h1>
        <p className="text-gray-600 dark:text-gray-300 my-4">
          Sua jornada pelo Brasil está prestes a começar! Faça o upload de uma imagem para ser seu avatar no mapa e escolha sua profissão inicial.
        </p>
        
        <div className="grid md:grid-cols-2 gap-8 items-center">
            {/* Image Upload Area */}
            <div 
              className="h-64 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg flex items-center justify-center cursor-pointer hover:border-green-500 hover:bg-green-50 dark:hover:bg-gray-800 transition-colors"
              onClick={() => fileInputRef.current?.click()}
              onDrop={handleDrop}
              onDragOver={(e) => e.preventDefault()}
            >
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                className="hidden"
                accept="image/png, image/jpeg, image/gif"
              />
              {croppedImage ? (
                <div className="w-48 h-48 relative">
                    <img src={croppedImage} alt="Avatar Preview" className="w-full h-full object-cover rounded-full shadow-lg" />
                    <div className="absolute inset-0 rounded-full border-4 border-yellow-400"></div>
                </div>
              ) : (
                <div className="text-gray-400">
                  <UploadCloud className="mx-auto w-12 h-12" />
                  <p>Arraste ou clique para enviar</p>
                  <p className="text-xs mt-1">PNG, JPG, GIF (Max 5MB)</p>
                </div>
              )}
            </div>

            {/* Profession Selection */}
            <div>
                 <h2 className="text-xl font-semibold mb-4">Escolha sua Profissão</h2>
                <select 
                    value={profession} 
                    onChange={e => setProfession(e.target.value as Profession)} 
                    className="w-full p-3 border rounded-lg bg-gray-50 dark:bg-gray-700 dark:border-gray-600"
                >
                    {PROFESSIONS.map(prof => <option key={prof} value={prof}>{prof}</option>)}
                </select>
            </div>
        </div>

        {error && <p className="text-red-500 mt-4">{error}</p>}

        <div className="mt-8">
           <Button onClick={handleCreate} className="w-full max-w-md mx-auto text-lg py-3" disabled={!croppedImage}>
             Iniciar Aventura!
           </Button>
        </div>
      </div>
      
      {imageToCrop && (
        <AvatarCropper
          imageSrc={imageToCrop}
          onCropComplete={(img) => {
            setCroppedImage(img);
            setImageToCrop(null);
          }}
          onCancel={() => setImageToCrop(null)}
        />
      )}
    </div>
  );
};

export default AvatarCreator;