import React from 'react';
import { Avatar } from '../../types';

interface VectorAvatarDisplayProps {
  avatar: Avatar;
}

const VectorAvatarDisplay: React.FC<VectorAvatarDisplayProps> = ({ avatar }) => {
    const hairStyles: { [key: string]: React.ReactNode } = {
        'curto': <path d="M 25,40 C 25,15 75,15 75,40 L 70,40 C 70,20 30,20 30,40 Z" />,
        'longo': <path d="M 25,40 C 25,15 75,15 75,40 V 70 H 25 Z" />,
        'cacheado': <>
            <circle cx="50" cy="25" r="25" />
            <circle cx="30" cy="30" r="15" />
            <circle cx="70" cy="30" r="15" />
            <circle cx="50" cy="45" r="20" />
        </>,
        'black-power': <circle cx="50" cy="30" r="30" />,
    };

    const skinColor = avatar.skinColor || '#E0AC69';
    const hairColor = avatar.hairColor || '#2E1F27';
    const hairStyle = avatar.hairStyle || 'curto';

    return (
      <div className="w-full h-full rounded-full overflow-hidden border-2 border-yellow-400" style={{ backgroundColor: skinColor }}>
        <svg viewBox="0 0 100 100" className="w-full h-full">
            <g id="face-and-ears">
                <path d="M 50,20 C 25,20 15,45 15,65 C 15,90 30,100 50,100 C 70,100 85,90 85,65 C 85,45 75,20 50,20 Z" fill={skinColor} />
            </g>
            <g id="hair" fill={hairColor}>
                {hairStyles[hairStyle] || hairStyles['curto']}
            </g>
            <g id="features" fill="#000000" stroke="none">
                <circle cx="38" cy="60" r="4" />
                <circle cx="62" cy="60" r="4" />
                <path d="M 45,78 A 10,5 0 0,0 55,78" fill="none" stroke="#000000" strokeWidth="2" />
            </g>
        </svg>
    </div>
    );
};

export default VectorAvatarDisplay;