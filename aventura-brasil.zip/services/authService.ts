
import { User, Admin } from '../types';
import { ADMIN_USER, ADMIN_PASSWORD } from '../constants';

const USERS_KEY = 'aventura_brasil_users';
const CURRENT_USER_KEY = 'aventura_brasil_current_user';

class AuthService {
  private getUsers(): (User | Admin)[] {
    const usersJson = localStorage.getItem(USERS_KEY);
    return usersJson ? JSON.parse(usersJson) : [];
  }

  private saveUsers(users: (User | Admin)[]): void {
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
  }
  
  private setCurrentUser(user: User | Admin): void {
    localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
  }

  login(username: string, password: string): Promise<User | Admin | null> {
    return new Promise((resolve) => {
      setTimeout(() => {
        if (username === ADMIN_USER && password === ADMIN_PASSWORD) {
          const admin: Admin = { id: 'admin', username: ADMIN_USER, role: 'admin' };
          this.setCurrentUser(admin);
          resolve(admin);
          return;
        }

        const users = this.getUsers();
        const user = users.find(u => u.username === username && (u as User).password === password);
        
        if (user) {
          this.setCurrentUser(user);
          resolve(user as User | Admin);
        } else {
          resolve(null);
        }
      }, 500);
    });
  }

  register(username: string, password: string): Promise<User | null> {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const users = this.getUsers();
        if (users.some(u => u.username === username) || username === ADMIN_USER) {
          reject(new Error('Nome de usuário já existe.'));
          return;
        }

        const newUser: User = {
          id: `user_${Date.now()}`,
          username,
          password,
          role: 'player',
          xp: 0,
          level: 1,
          completedBiomes: [],
          inventory: [],
        };

        users.push(newUser);
        this.saveUsers(users);
        this.setCurrentUser(newUser);
        resolve(newUser);
      }, 500);
    });
  }

  logout(): void {
    localStorage.removeItem(CURRENT_USER_KEY);
  }
  
  getCurrentUser(): User | Admin | null {
    const userJson = localStorage.getItem(CURRENT_USER_KEY);
    return userJson ? JSON.parse(userJson) : null;
  }
  
  updateUser(updatedUser: User): User | null {
      const users = this.getUsers();
      const userIndex = users.findIndex(u => u.id === updatedUser.id);
      if (userIndex !== -1) {
          // Keep password if not provided
          const oldPassword = (users[userIndex] as User).password;
          users[userIndex] = { ...updatedUser, password: updatedUser.password || oldPassword };
          this.saveUsers(users);
          this.setCurrentUser(users[userIndex] as User);
          return users[userIndex] as User;
      }
      return null;
  }
}

export const authService = new AuthService();
