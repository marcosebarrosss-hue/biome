import React from 'react';
import { User } from '../../types';
import { adminService } from '../../services/adminService';
import PlayerAvatar from '../common/PlayerAvatar';

interface ProfileProps {
  user: User;
}

const Profile: React.FC<ProfileProps> = ({ user }) => {
  const allItems = adminService.getItems();
  const inventoryItems = user.inventory.map(id => allItems.find(item => item.id === id)).filter(Boolean);
  
  return (
    <div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-1 flex flex-col items-center">
                 {user.avatar && (
                     <div className="relative">
                        <PlayerAvatar user={user} className="w-48 h-48" />
                        <div className="absolute top-0 right-0 -mt-2 -mr-2 bg-blue-500 text-white text-xs rounded-full px-2 py-1 shadow-lg">
                            {user.profession}
                        </div>
                     </div>
                 )}
                <h3 className="text-2xl font-bold mt-4">{user.username}</h3>
                <p className="text-gray-500 dark:text-gray-400">Nível {user.level}</p>
            </div>
            <div className="md:col-span-2 space-y-4">
                <div>
                    <h4 className="font-bold text-lg mb-2">Estatísticas</h4>
                    <div className="bg-gray-100 dark:bg-gray-700 p-4 rounded-lg grid grid-cols-2 gap-4">
                        <div>
                            <p className="text-sm text-gray-500 dark:text-gray-400">XP Total</p>
                            <p className="text-2xl font-semibold text-yellow-500">{user.xp}</p>
                        </div>
                        <div>
                            <p className="text-sm text-gray-500 dark:text-gray-400">Biomas Concluídos</p>
                            <p className="text-2xl font-semibold text-green-500">{user.completedBiomes.length}</p>
                        </div>
                    </div>
                </div>
                <div>
                    <h4 className="font-bold text-lg mb-2">Inventário de Itens</h4>
                    <div className="bg-gray-100 dark:bg-gray-700 p-4 rounded-lg max-h-48 overflow-y-auto">
                        {inventoryItems.length > 0 ? (
                            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-4">
                                {inventoryItems.map(item => item && (
                                    <div key={item.id} className="flex flex-col items-center text-center group" title={item.name}>
                                        <div className="w-16 h-16 bg-white/50 dark:bg-gray-800/50 rounded-lg flex items-center justify-center p-1">
                                            <img src={item.imageUrl} alt={item.name} className="max-w-full max-h-full object-contain" />
                                        </div>
                                        <p className="text-xs mt-1 truncate w-full">{item.name}</p>
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <p className="text-gray-500 dark:text-gray-400">Seu inventário está vazio. Explore para ganhar itens!</p>
                        )}
                    </div>
                </div>
            </div>
        </div>
    </div>
  );
};

export default Profile;