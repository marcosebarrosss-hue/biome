import React, { useState, useEffect } from 'react';
import { Biome, User } from '../../types';
import { gameService } from '../../services/gameService';
import { useAuth } from '../../App';
import Button from '../common/Button';
import { adminService } from '../../services/adminService';
import { authService } from '../../services/authService';

interface QuizProps {
  biome: Biome;
  onQuizComplete: () => void;
}

const Quiz: React.FC<QuizProps> = ({ biome, onQuizComplete }) => {
  const { currentUser, updateUser } = useAuth();
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [xpChange, setXpChange] = useState(0);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [quizFinished, setQuizFinished] = useState(false);
  const [quizResult, setQuizResult] = useState({ passed: false, message: '', xpBreakdown: '' });

  const question = biome.quiz[currentQuestionIndex];

  const handleAnswer = (option: string) => {
    if (isAnswered) return;

    setSelectedOption(option);
    setIsAnswered(true);

    if (option === question.correctAnswer) {
      setScore(s => s + 1);
      setXpChange(c => c + 100);
    } else {
      setXpChange(c => c - 50);
    }
  };

  const handleNext = () => {
    if (currentQuestionIndex < biome.quiz.length - 1) {
      setCurrentQuestionIndex(i => i + 1);
      setSelectedOption(null);
      setIsAnswered(false);
    } else {
      // Finaliza o quiz e processa o resultado
      if (currentUser && currentUser.role === 'player') {
        const player = currentUser as User;
        const passed = score === biome.quiz.length; // CORREÇÃO: A condição de passar agora é acertar tudo.
        
        let finalXp = player.xp + xpChange;
        const correctAnswers = score;
        const incorrectAnswers = biome.quiz.length - score;
        let breakdown = `Respostas corretas: +${correctAnswers * 100} XP, Respostas erradas: -${incorrectAnswers * 50} XP.`;

        if (passed) {
          finalXp += 300; // Bônus de conclusão
          const updatedUser: User = {
            ...player,
            xp: finalXp,
            level: Math.floor(finalXp / 100) + 1,
            completedBiomes: [...player.completedBiomes, biome.id],
            inventory: [...player.inventory, biome.rewardItemId],
          };
          updateUser(authService.updateUser(updatedUser) as User);
          setQuizResult({
            passed: true,
            message: `Você concluiu o módulo ${biome.name} com perfeição!`,
            xpBreakdown: breakdown + ' Bônus: +300 XP.',
          });
        } else {
          const updatedUser: User = {
            ...player,
            xp: Math.max(0, finalXp), // Garante que o XP não fique negativo
            level: Math.floor(Math.max(0, finalXp) / 100) + 1,
          };
          updateUser(authService.updateUser(updatedUser) as User);
           setQuizResult({
            passed: false,
            message: 'Você precisa acertar todas as questões para avançar. Tente novamente!',
            xpBreakdown: breakdown,
          });
        }
      }
      setQuizFinished(true);
    }
  };

  const getButtonClass = (option: string) => {
    if (!isAnswered) return 'bg-gray-200 dark:bg-gray-600 hover:bg-gray-300 dark:hover:bg-gray-500';
    if (option === question.correctAnswer) return 'bg-green-500 text-white';
    if (option === selectedOption && option !== question.correctAnswer) return 'bg-red-500 text-white';
    return 'bg-gray-200 dark:bg-gray-600 opacity-50';
  };

  if (quizFinished) {
    const reward = adminService.getItems().find(i => i.id === biome.rewardItemId);
    return (
      <div className="text-center p-4 flex flex-col items-center">
        <h2 className="text-2xl font-bold mb-4">{quizResult.passed ? "Parabéns, Mestre Aventureiro!" : "Quase lá!"}</h2>
        <p className="text-lg mb-2">{quizResult.message}</p>
        <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">({quizResult.xpBreakdown})</p>
        
        {quizResult.passed && reward && (
          <div className="flex flex-col items-center gap-2 bg-yellow-100 dark:bg-yellow-900/50 p-4 rounded-lg my-4">
            <p className="mb-2 font-semibold">Sua recompensa:</p>
            <img src={reward.imageUrl} alt={reward.name} className="w-24 h-24" />
            <p className="font-bold text-yellow-600 dark:text-yellow-400">{reward.name}</p>
          </div>
        )}

        {quizResult.passed && <p className="mt-2">Um novo bioma foi desbloqueado no mapa!</p>}

        <Button onClick={onQuizComplete} className="mt-6">Voltar ao Mapa</Button>
      </div>
    );
  }

  return (
    <div>
      <h3 className="text-xl font-semibold mb-4">Questão {currentQuestionIndex + 1}/{biome.quiz.length}</h3>
      <p className="text-lg mb-6">{question.question}</p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {question.options.map(option => (
          <button
            key={option}
            onClick={() => handleAnswer(option)}
            disabled={isAnswered}
            className={`p-4 rounded-lg text-left transition-colors ${getButtonClass(option)}`}
          >
            {option}
          </button>
        ))}
      </div>

      {isAnswered && (
        <div className="mt-6 text-center">
          <Button onClick={handleNext}>
            {currentQuestionIndex < biome.quiz.length - 1 ? 'Próxima Pergunta' : 'Finalizar Desafio'}
          </Button>
        </div>
      )}
    </div>
  );
};

export default Quiz;