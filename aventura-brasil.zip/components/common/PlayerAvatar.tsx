import React from 'react';
import { User, Item } from '../../types';
import { useTheme } from '../../App';
import { adminService } from '../../services/adminService';

interface PlayerAvatarProps {
  user: User;
  className?: string;
}

const allItems = adminService.getItems();

const PlayerAvatar: React.FC<PlayerAvatarProps> = ({ user, className }) => {
    const theme = useTheme();

    if (!user.avatar) {
        return <div className={`bg-gray-300 rounded-full ${className}`} />;
    }

    const baseAvatarUrl = user.avatar.imageUrl;
    
    const equippedItems = user.inventory
        .map(itemId => allItems.find(item => item.id === itemId))
        .filter((item): item is Item => !!item && !!item.wearableImageUrl);

    return (
        <div className={`relative flex-shrink-0 overflow-hidden ${className}`}>
            <img 
              src={baseAvatarUrl} 
              alt="Avatar" 
              className="w-full h-full object-contain" 
            />
            {equippedItems.map(item => (
                <img
                    key={item.id}
                    src={item.wearableImageUrl}
                    alt={item.name}
                    style={item.wearableStyle as React.CSSProperties}
                    className="absolute pointer-events-none"
                />
            ))}
        </div>
    );
};

export default PlayerAvatar;