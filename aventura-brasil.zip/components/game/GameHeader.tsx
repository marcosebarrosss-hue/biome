import React from 'react';
import { User, Admin } from '../../types';
import { useAdminEdit, useTheme } from '../../App';
import { LogOut, User as UserIcon, BarChart3 } from 'lucide-react';
import EditableImage from '../common/EditableImage';
import PlayerAvatar from '../common/PlayerAvatar';

interface GameHeaderProps {
  user: User | Admin;
  onProfileClick: () => void;
  onRankingClick: () => void;
  onLogout: () => void;
}

const XpBar: React.FC<{ xp: number; level: number }> = ({ xp, level }) => {
    const xpForNextLevel = level * 100;
    const currentLevelXp = xp - ((level - 1) * 100);
    const progress = Math.min((currentLevelXp / 100) * 100, 100);

    return (
        <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-4 relative">
            <div
                className="bg-yellow-400 h-4 rounded-full transition-all duration-500"
                style={{ width: `${progress}%` }}
            ></div>
            <span className="absolute inset-0 flex items-center justify-center text-xs font-bold text-gray-800 dark:text-gray-900">{`${currentLevelXp} / 100 XP`}</span>
        </div>
    );
};


const GameHeader: React.FC<GameHeaderProps> = ({ user, onProfileClick, onRankingClick, onLogout }) => {
  const theme = useTheme();
  const adminContext = useAdminEdit();
  const isPlayer = user.role === 'player';

  return (
    <header className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm shadow-md p-2 flex justify-between items-center z-10">
      <div className="flex items-center gap-4">
        <EditableImage
            src={theme.logoUrl}
            alt="Logo"
            className="h-12 w-12 object-contain"
            containerClassName="w-12 h-12"
            onImageChange={(newSrc) => adminContext?.setTheme(t => ({...t, logoUrl: newSrc}))}
            allowCropping
        />
        <div className="flex items-center gap-3">
            {isPlayer && (user as User).avatar && (
              <PlayerAvatar user={user as User} className="w-12 h-12" />
            )}
            {user.role === 'admin' && (
              <img src={theme.adminAvatarUrl} alt="Admin Avatar" className="w-12 h-12 rounded-full object-cover bg-gray-200" />
            )}
            <div>
                <h2 className="font-bold text-lg">{user.username}</h2>
                {isPlayer && <p className="text-sm text-gray-600 dark:text-gray-400">Nível {(user as User).level}</p>}
                {user.role === 'admin' && <p className="text-sm text-red-500 dark:text-red-400">Administrador</p>}
            </div>
        </div>
      </div>
      
      {isPlayer && (
        <div className="w-1/4">
          <XpBar xp={(user as User).xp} level={(user as User).level} />
        </div>
      )}

      <div className="flex items-center gap-2">
        {isPlayer && (
          <>
            <button onClick={onProfileClick} className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors" title="Meu Perfil">
                <UserIcon className="w-6 h-6 text-green-600" />
            </button>
            <button onClick={onRankingClick} className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors" title="Ranking">
                <BarChart3 className="w-6 h-6 text-yellow-500" />
            </button>
          </>
        )}
        <button onClick={onLogout} className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors" title="Sair">
            <LogOut className="w-6 h-6 text-red-500" />
        </button>
      </div>
    </header>
  );
};

export default GameHeader;