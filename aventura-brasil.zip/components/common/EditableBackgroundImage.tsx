import React, { useRef } from 'react';
import { useAdminEdit } from '../../App';
import { Upload } from 'lucide-react';

interface EditableBackgroundImageProps {
  src: string;
  onImageChange: (newSrc: string) => void;
  children: React.ReactNode;
  className?: string;
  backgroundSize?: string;
  backgroundPosition?: string;
}

const EditableBackgroundImage: React.FC<EditableBackgroundImageProps> = ({ src, onImageChange, children, className, backgroundSize = 'cover', backgroundPosition = 'center' }) => {
  const adminContext = useAdminEdit();
  const isEditMode = adminContext?.isEditMode ?? false;
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          onImageChange(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div
      className={`relative bg-center bg-no-repeat group ${className}`}
      style={{ 
        backgroundImage: `url(${src})`,
        backgroundSize: backgroundSize,
        backgroundPosition: backgroundPosition,
      }}
    >
      {children}
      {isEditMode && (
        <>
          <div 
            className="absolute top-28 right-4 z-20"
          >
            <button
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center gap-2 px-4 py-2 bg-white text-black font-semibold rounded-lg shadow-lg hover:bg-gray-200 transition-colors"
              aria-label="Substituir imagem de fundo"
            >
              <Upload size={16} />
              <span>Substituir Fundo</span>
            </button>
          </div>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            className="hidden"
            accept="image/*"
          />
        </>
      )}
    </div>
  );
};

export default EditableBackgroundImage;