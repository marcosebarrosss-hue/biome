
import React, { useState, useEffect } from 'react';
import { User } from '../../types';
import { adminService } from '../../services/adminService';
import PlayerAvatar from '../common/PlayerAvatar';

const Ranking: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);

  useEffect(() => {
    const allUsers = adminService.getAllUsers();
    allUsers.sort((a, b) => b.xp - a.xp);
    setUsers(allUsers);
  }, []);

  const getRankColor = (index: number) => {
      if (index === 0) return 'text-yellow-400';
      if (index === 1) return 'text-gray-400';
      if (index === 2) return 'text-orange-400';
      return '';
  }

  return (
    <div className="w-full">
      <ul className="space-y-2">
        {users.map((user, index) => (
          <li key={user.id} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
            <div className="flex items-center gap-4">
              <span className={`text-2xl font-bold w-8 text-center ${getRankColor(index)}`}>{index + 1}</span>
              {user.avatar ? (
                <PlayerAvatar user={user} className="w-12 h-12" />
              ) : (
                <div className="w-12 h-12 rounded-full bg-gray-300"></div>
              )}
              <div>
                <p className="font-semibold">{user.username}</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">Nível {user.level}</p>
              </div>
            </div>
            <div className="text-right">
                <p className="font-bold text-lg text-yellow-500">{user.xp} XP</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">{user.completedBiomes.length} Biomas</p>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Ranking;