import React, { useRef, useState } from 'react';
import { useAdminEdit, useTheme } from '../../App';
import { Upload, Trash2, ImagePlus } from 'lucide-react';
import ImageCropper from './ImageCropper'; // Assuming ImageCropper is in the same directory

interface EditableImageProps {
  src: string;
  alt: string;
  onImageChange: (newSrc: string) => void;
  onImageRemove?: () => void;
  className?: string;
  containerClassName?: string;
  style?: React.CSSProperties;
  allowCropping?: boolean;
}

const EditableImage: React.FC<EditableImageProps> = ({ src, alt, onImageChange, onImageRemove, className, containerClassName, style, allowCropping = false }) => {
  const adminContext = useAdminEdit();
  const theme = useTheme();
  const isEditMode = adminContext?.isEditMode ?? false;
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [imageToCrop, setImageToCrop] = useState<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        if (allowCropping) {
          setImageToCrop(result);
        } else if (typeof result === 'string') {
          onImageChange(result);
        }
      };
      reader.readAsDataURL(file);
    }
    e.target.value = ''; // Reset input to allow re-uploading the same file
  };

  const handleCropComplete = (croppedImage: string) => {
    onImageChange(croppedImage);
    setImageToCrop(null);
  };

  const isPlaceholder = !src || src === theme.placeholderImageUrl;

  if (isEditMode && isPlaceholder) {
    return (
      <div className={`relative group ${containerClassName} bg-gray-100 dark:bg-gray-700 rounded-lg flex items-center justify-center border-2 border-dashed`}>
        <button
          onClick={() => fileInputRef.current?.click()}
          className="flex flex-col items-center gap-2 p-4 text-gray-500 hover:text-green-600 transition-colors"
          aria-label={`Adicionar ${alt}`}
        >
          <ImagePlus size={32} />
          <span className="text-xs font-semibold">Adicionar Imagem</span>
        </button>
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          className="hidden"
          accept="image/*"
        />
        {imageToCrop && (
          <ImageCropper
            imageSrc={imageToCrop}
            onCropComplete={handleCropComplete}
            onCancel={() => setImageToCrop(null)}
          />
        )}
      </div>
    );
  }

  return (
    <div className={`relative group ${containerClassName}`}>
      <img src={src || theme.placeholderImageUrl} alt={alt} className={className} style={style} />
      {isEditMode && (
        <>
          <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center gap-2">
            <button
              onClick={() => fileInputRef.current?.click()}
              className="p-2 bg-white text-black rounded-full shadow-md hover:bg-gray-200 transition-transform hover:scale-110"
              aria-label={`Substituir ${alt}`}
              title="Substituir"
            >
              <Upload size={18} />
            </button>
            {onImageRemove && !isPlaceholder && (
              <button
                onClick={onImageRemove}
                className="p-2 bg-red-600 text-white rounded-full shadow-md hover:bg-red-700 transition-transform hover:scale-110"
                aria-label={`Remover ${alt}`}
                title="Remover"
              >
                <Trash2 size={18} />
              </button>
            )}
          </div>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            className="hidden"
            accept="image/*"
          />
        </>
      )}
      {imageToCrop && (
        <ImageCropper
          imageSrc={imageToCrop}
          onCropComplete={handleCropComplete}
          onCancel={() => setImageToCrop(null)}
        />
      )}
    </div>
  );
};

export default EditableImage;
