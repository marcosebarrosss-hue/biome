import React, { useState, ChangeEvent } from 'react';
import { Item, BiomeId } from '../../types';
import { useAdminEdit, useTheme } from '../../App';
import Modal from '../common/Modal';
import Button from '../common/Button';
import EditableImage from '../common/EditableImage';
import { BIOMES } from '../../constants';

const ItemManagement: React.FC = () => {
    const context = useAdminEdit();
    const theme = useTheme();

    if (!context) return null;

    const { items, setItems } = context;
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingItem, setEditingItem] = useState<Partial<Item> | null>(null);

    const handleEdit = (item: Item) => {
        setEditingItem(JSON.parse(JSON.stringify(item))); // Deep copy to avoid mutation
        setIsModalOpen(true);
    };

    const handleAddNew = () => {
        setEditingItem({
            id: `item_${Date.now()}`,
            name: 'Novo Item',
            description: '',
            imageUrl: theme.placeholderImageUrl,
            type: 'equipment',
            biome: BiomeId.Amazonia,
            wearableImageUrl: '',
            wearableStyle: { position: 'absolute' }
        });
        setIsModalOpen(true);
    };

    const handleDelete = (itemId: string) => {
        if (window.confirm('Tem certeza que deseja excluir este item? Isso pode afetar biomas que o utilizam como recompensa.')) {
            setItems(items.filter(item => item.id !== itemId));
        }
    };

    const handleSave = () => {
        if (!editingItem) return;

        const isNew = !items.some(item => item.id === editingItem.id);
        if (isNew) {
            setItems([...items, editingItem as Item]);
        } else {
            setItems(items.map(item => item.id === editingItem.id ? editingItem as Item : item));
        }
        setIsModalOpen(false);
        setEditingItem(null);
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        if (!editingItem) return;
        const { name, value } = e.target;
        setEditingItem({ ...editingItem, [name]: value });
    };

    const handleStyleChange = (e: ChangeEvent<HTMLInputElement>) => {
        if (!editingItem) return;
        const { name, value } = e.target;
        setEditingItem(prev => ({
            ...prev,
            wearableStyle: { ...(prev?.wearableStyle || {}), [name]: value }
        }));
    };

    return (
        <div>
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold">Gerenciar Itens de Recompensa</h2>
                <Button onClick={handleAddNew}>Adicionar Novo Item</Button>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 max-h-[60vh] overflow-y-auto p-2">
                {items.map(item => (
                    <div key={item.id} className="p-2 border dark:border-gray-700 rounded-lg text-center flex flex-col justify-between">
                        <EditableImage
                            src={item.imageUrl}
                            alt={item.name}
                            onImageChange={(newSrc) => setItems(items.map(i => i.id === item.id ? { ...i, imageUrl: newSrc } : i))}
                            onImageRemove={() => setItems(items.map(i => i.id === item.id ? { ...i, imageUrl: theme.placeholderImageUrl } : i))}
                            containerClassName="w-24 h-24 mx-auto mb-2"
                            className="w-full h-full object-contain"
                        />
                        <p className="font-semibold text-sm mb-2">{item.name}</p>
                        <div className="flex justify-center gap-2">
                            <Button variant="secondary" onClick={() => handleEdit(item)} className="text-xs px-2 py-1">Editar</Button>
                            <Button variant="danger" onClick={() => handleDelete(item.id)} className="text-xs px-2 py-1">Excluir</Button>
                        </div>
                    </div>
                ))}
            </div>

            <Modal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                title={editingItem?.id && items.some(i => i.id === editingItem.id) ? 'Editar Item' : 'Adicionar Item'}
                isResizable
                initialBounds={{ width: '600px', height: 'auto', }}
            >
                {editingItem && (
                    <div className="space-y-4">
                        {/* General Info */}
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block">Nome</label>
                                <input name="name" value={editingItem.name} onChange={handleChange} className="w-full p-2 border rounded dark:bg-gray-700" />
                            </div>
                            <div>
                                <label className="block">Tipo</label>
                                <select name="type" value={editingItem.type} onChange={handleChange} className="w-full p-2 border rounded dark:bg-gray-700">
                                    <option value="equipment">Equipamento</option>
                                    <option value="clothing">Vestimenta</option>
                                </select>
                            </div>
                        </div>
                        <div>
                            <label className="block">Descrição</label>
                            <textarea name="description" value={editingItem.description} onChange={handleChange} className="w-full p-2 border rounded dark:bg-gray-700 h-20" />
                        </div>
                        <div>
                            <label className="block">Bioma Associado (para referência)</label>
                            <select name="biome" value={editingItem.biome} onChange={handleChange} className="w-full p-2 border rounded dark:bg-gray-700">
                                {BIOMES.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                            </select>
                        </div>

                        {/* Wearable Properties */}
                        <div className="border-t pt-4 mt-4 dark:border-gray-600">
                            <h3 className="font-semibold text-lg mb-2">Propriedades do Item Vestível</h3>
                            <div className="flex gap-4 items-start">
                                <EditableImage
                                    src={editingItem.wearableImageUrl || theme.placeholderImageUrl}
                                    alt="Imagem vestível"
                                    onImageChange={(newSrc) => setEditingItem(prev => ({ ...prev, wearableImageUrl: newSrc }))}
                                    onImageRemove={() => setEditingItem(prev => ({ ...prev, wearableImageUrl: '' }))}
                                    containerClassName="w-32 h-32 flex-shrink-0"
                                    className="w-full h-full object-contain"
                                />
                                <div className="grid grid-cols-2 gap-x-4 gap-y-2 flex-grow">
                                    <div>
                                        <label className="text-sm">Posição (top)</label>
                                        <input name="top" value={editingItem.wearableStyle?.top || ''} onChange={handleStyleChange} className="w-full p-1 border rounded dark:bg-gray-600 text-sm" placeholder="ex: -5%" />
                                    </div>
                                    <div>
                                        <label className="text-sm">Posição (left)</label>
                                        <input name="left" value={editingItem.wearableStyle?.left || ''} onChange={handleStyleChange} className="w-full p-1 border rounded dark:bg-gray-600 text-sm" placeholder="ex: 12%" />
                                    </div>
                                     <div>
                                        <label className="text-sm">Posição (bottom)</label>
                                        <input name="bottom" value={editingItem.wearableStyle?.bottom || ''} onChange={handleStyleChange} className="w-full p-1 border rounded dark:bg-gray-600 text-sm" placeholder="ex: 10%" />
                                    </div>
                                     <div>
                                        <label className="text-sm">Posição (right)</label>
                                        <input name="right" value={editingItem.wearableStyle?.right || ''} onChange={handleStyleChange} className="w-full p-1 border rounded dark:bg-gray-600 text-sm" placeholder="ex: 0%" />
                                    </div>
                                    <div>
                                        <label className="text-sm">Largura (width)</label>
                                        <input name="width" value={editingItem.wearableStyle?.width || ''} onChange={handleStyleChange} className="w-full p-1 border rounded dark:bg-gray-600 text-sm" placeholder="ex: 75%" />
                                    </div>
                                    <div>
                                        <label className="text-sm">Z-Index</label>
                                        <input name="zIndex" type="number" value={editingItem.wearableStyle?.zIndex || ''} onChange={handleStyleChange} className="w-full p-1 border rounded dark:bg-gray-600 text-sm" placeholder="ex: 1" />
                                    </div>
                                    <div className="col-span-2">
                                        <label className="text-sm">Transformação (transform)</label>
                                        <input name="transform" value={editingItem.wearableStyle?.transform || ''} onChange={handleStyleChange} className="w-full p-1 border rounded dark:bg-gray-600 text-sm" placeholder="ex: rotate(-20deg)" />
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="flex justify-end gap-4 pt-4 border-t dark:border-gray-600">
                            <Button variant="secondary" onClick={() => setIsModalOpen(false)}>Cancelar</Button>
                            <Button onClick={handleSave}>Salvar Item</Button>
                        </div>
                    </div>
                )}
            </Modal>
        </div>
    );
};

export default ItemManagement;
