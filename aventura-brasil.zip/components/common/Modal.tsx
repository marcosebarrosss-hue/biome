import React, { useRef, useEffect, useState } from 'react';

type Direction = 'nw' | 'ne' | 'sw' | 'se';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  children: React.ReactNode;
  title: string;
  isResizable?: boolean;
  initialBounds?: { width: string; height: string; x?: number; y?: number };
  onBoundsChange?: (newBounds: { width: string; height: string; x: number; y: number; }) => void;
  maxWidthClass?: string; // No longer primary, but kept as a potential fallback
}

const parseSize = (value: string, dimension: 'width' | 'height'): number => {
    if (value === 'auto') {
        return dimension === 'width' ? window.innerWidth * 0.5 : window.innerHeight * 0.7;
    }
    if (value.endsWith('px')) {
        return parseFloat(value);
    }
    if (value.endsWith('vw')) {
        return (parseFloat(value) / 100) * window.innerWidth;
    }
    if (value.endsWith('vh')) {
        return (parseFloat(value) / 100) * window.innerHeight;
    }
    return parseFloat(value) || 500;
};

const Modal: React.FC<ModalProps> = ({ isOpen, onClose, children, title, isResizable = false, initialBounds, onBoundsChange }) => {
  const modalRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isResizing, setIsResizing] = useState<Direction | null>(null);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [size, setSize] = useState< { width: number, height: number | 'auto' } >({ width: 0, height: 'auto' });
  const startMousePos = useRef({ x: 0, y: 0 });
  const startSize = useRef({ width: 0, height: 0});
  
  useEffect(() => {
    if (isOpen) {
        const width = parseSize(initialBounds?.width || '50vw', 'width');
        const height = initialBounds?.height === 'auto' ? 'auto' : parseSize(initialBounds?.height || '70vh', 'height');
        
        setSize({ width, height });
        
        const yPos = initialBounds?.y ?? (window.innerHeight - (typeof height === 'number' ? height : window.innerHeight * 0.7)) / 2;

        setPosition({ 
            x: initialBounds?.x ?? (window.innerWidth - width) / 2, 
            y: Math.max(0, yPos) // Ensure modal doesn't start off-screen at the top
        });
    }
  }, [isOpen, initialBounds]);

  const handleMouseDownDrag = (e: React.MouseEvent) => {
    if (!isResizable) return;
    e.preventDefault();
    setIsDragging(true);
    startMousePos.current = { x: e.clientX - position.x, y: e.clientY - position.y };
  };

  const handleMouseDownResize = (e: React.MouseEvent, direction: Direction) => {
    if (!isResizable) return;
    e.preventDefault();
    e.stopPropagation();
    setIsResizing(direction);
    startMousePos.current = { x: e.clientX, y: e.clientY };
    const currentHeight = modalRef.current?.offsetHeight || (typeof size.height === 'number' ? size.height : 500);
    startSize.current = { width: size.width, height: currentHeight };
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (isDragging) {
        setPosition({
          x: e.clientX - startMousePos.current.x,
          y: e.clientY - startMousePos.current.y,
        });
      } else if (isResizing) {
        const dx = e.clientX - startMousePos.current.x;
        const dy = e.clientY - startMousePos.current.y;
        
        setSize(prevSize => {
            let newWidth = startSize.current.width;
            let newHeight = startSize.current.height;
            let newX = position.x;
            let newY = position.y;

            if (isResizing.includes('e')) newWidth = startSize.current.width + dx;
            if (isResizing.includes('w')) {
                newWidth = startSize.current.width - dx;
                newX = position.x + dx;
            }
            if (isResizing.includes('s')) newHeight = startSize.current.height + dy;
            if (isResizing.includes('n')) {
                newHeight = startSize.current.height - dy;
                newY = position.y + dy;
            }
            
            const finalWidth = Math.max(320, newWidth);
            const finalHeight = Math.max(200, newHeight);

            if (finalWidth > 320 && isResizing.includes('w')) setPosition(p => ({ ...p, x: newX }));
            if (finalHeight > 200 && isResizing.includes('n')) setPosition(p => ({ ...p, y: newY }));

            return { width: finalWidth, height: finalHeight };
        });
      }
    };
    
    const handleMouseUp = () => {
      if((isDragging || isResizing) && onBoundsChange) {
          const finalHeight = modalRef.current?.offsetHeight || (typeof size.height === 'number' ? size.height : 500);
          onBoundsChange({
              width: `${size.width}px`, 
              height: `${finalHeight}px`,
              x: position.x,
              y: position.y
          });
      }
      setIsDragging(false);
      setIsResizing(null);
    };

    if (isOpen && isResizable && (isDragging || isResizing)) {
        window.addEventListener('mousemove', handleMouseMove);
        window.addEventListener('mouseup', handleMouseUp);
    }

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging, isResizing, isOpen, size, position, onBoundsChange, isResizable]);


  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-25 z-50 pointer-events-none">
        <div 
            ref={modalRef} 
            className="absolute bg-white dark:bg-gray-800 rounded-lg shadow-xl flex flex-col pointer-events-auto max-h-[95vh] overflow-hidden"
            style={{ 
                top: `${position.y}px`, 
                left: `${position.x}px`, 
                width: `${size.width}px`, 
                height: typeof size.height === 'number' ? `${size.height}px` : 'auto',
            }}
        >
            <div 
                onMouseDown={handleMouseDownDrag}
                className={`flex justify-between items-center p-4 border-b border-gray-200 dark:border-gray-700 flex-shrink-0 ${isResizable ? 'cursor-move' : ''}`}
            >
                <h2 className="text-xl font-bold text-gray-800 dark:text-gray-100">{title}</h2>
                <button onClick={onClose} className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                </button>
            </div>
            <div className="p-6 overflow-y-auto flex-grow">{children}</div>
            
            {isResizable && (
                <>
                    <div onMouseDown={(e) => handleMouseDownResize(e, 'nw')} className="absolute -top-1 -left-1 w-4 h-4 cursor-nwse-resize" />
                    <div onMouseDown={(e) => handleMouseDownResize(e, 'ne')} className="absolute -top-1 -right-1 w-4 h-4 cursor-nesw-resize" />
                    <div onMouseDown={(e) => handleMouseDownResize(e, 'sw')} className="absolute -bottom-1 -left-1 w-4 h-4 cursor-nesw-resize" />
                    <div onMouseDown={(e) => handleMouseDownResize(e, 'se')} className="absolute -bottom-1 -right-1 w-4 h-4 cursor-nwse-resize" />
                </>
            )}
      </div>
    </div>
  );
};

export default Modal;