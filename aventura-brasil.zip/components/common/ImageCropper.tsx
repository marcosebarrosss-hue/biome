import React, { useState, useRef } from 'react';
import Button from './Button';
import Modal from './Modal';
import { ZoomIn } from 'lucide-react';

interface ImageCropperProps {
  imageSrc: string;
  onCropComplete: (croppedImage: string) => void;
  onCancel: () => void;
  title?: string;
  cropShape?: 'round' | 'square';
}

const ImageCropper: React.FC<ImageCropperProps> = ({
  imageSrc,
  onCropComplete,
  onCancel,
  title = "Ajuste a Imagem",
  cropShape = 'round',
}) => {
  const imageRef = useRef<HTMLImageElement>(null);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState(false);
  const [panStart, setPanStart] = useState({ x: 0, y: 0 });
  const CROP_SIZE = 288; // 72 * 4

  const handleMouseDown = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsPanning(true);
    setPanStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isPanning) {
      setPan({ x: e.clientX - panStart.x, y: e.clientY - panStart.y });
    }
  };
  
  const handleMouseUp = () => setIsPanning(false);

  const handleCrop = () => {
    const image = imageRef.current;
    const canvas = document.createElement('canvas');
    const finalSize = 256;
    canvas.width = finalSize;
    canvas.height = finalSize;
    const ctx = canvas.getContext('2d');

    if (!ctx || !image) return;

    const scaleX = image.naturalWidth / image.width;
    const scaleY = image.naturalHeight / image.height;
    
    const sourceX = ( (image.width / 2) - pan.x - (CROP_SIZE / (2 * zoom)) ) * scaleX;
    const sourceY = ( (image.height / 2) - pan.y - (CROP_SIZE / (2 * zoom)) ) * scaleY;
    const sourceWidth = (CROP_SIZE / zoom) * scaleX;
    const sourceHeight = (CROP_SIZE / zoom) * scaleY;
    
    ctx.drawImage(
      image,
      sourceX,
      sourceY,
      sourceWidth,
      sourceHeight,
      0,
      0,
      finalSize,
      finalSize
    );

    onCropComplete(canvas.toDataURL('image/png'));
  };

  const cropClass = cropShape === 'round' ? 'rounded-full' : 'rounded-lg';

  return (
    <Modal isOpen={true} onClose={onCancel} title={title}>
      <div className="flex flex-col items-center">
        <p className="mb-4 text-center text-gray-600 dark:text-gray-300">Arraste para mover e use o controle para ampliar.</p>
        <div 
          className={`w-72 h-72 overflow-hidden relative bg-gray-200 dark:bg-gray-700 cursor-move ${cropClass}`}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
        >
          <img
            ref={imageRef}
            src={imageSrc}
            alt="Imagem para recortar"
            className="absolute top-1/2 left-1/2"
            style={{
              transform: `translate(-50%, -50%) translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
              transition: isPanning ? 'none' : 'transform 0.1s ease-out',
            }}
            onLoad={() => { // Reset pan/zoom on new image
                setPan({x:0, y:0});
                setZoom(1);
            }}
          />
        </div>
        <div className="w-72 mt-4 flex items-center gap-4">
          <ZoomIn className="text-gray-500" />
          <input
            type="range"
            min="1"
            max="3"
            step="0.01"
            value={zoom}
            onChange={(e) => setZoom(parseFloat(e.target.value))}
            className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-600"
          />
        </div>
        <div className="mt-6 flex gap-4">
          <Button variant="secondary" onClick={onCancel}>Cancelar</Button>
          <Button onClick={handleCrop}>Confirmar Ajuste</Button>
        </div>
      </div>
    </Modal>
  );
};

export default ImageCropper;
